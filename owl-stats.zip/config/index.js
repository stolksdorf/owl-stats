module.exports = require('pico-conf')
	.env()
	.file(`${process.env.NODE_ENV}.js`)
	.defaults(require('./default.js'));