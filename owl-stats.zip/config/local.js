module.exports = {
	gist : {
		token : '6fabcc3fd10adf1ebccd6de2be44affa7f6a77b3',
		id: 'd2e0a5ed9ce8003b4380185a336a47f5',
		//id: '4dd79913ce181180f1e2107b5230ec6a' //OWL Stats
	},
};