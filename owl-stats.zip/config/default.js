module.exports = {
	gist : {
		token : '',
		id : ''
	},
	lambda_gist : ''

};